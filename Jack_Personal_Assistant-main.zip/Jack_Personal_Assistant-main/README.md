# Jack Personal Assistant

JAck personal assistant is an interactive voice assistant which has the following functions:

FEATURES 
- Weather
- Date, Time
- Password generation
- WhatsApp message
- Email
- Jokes
- Covid updates
- News updates
- Shut down and restart
- CPU Usage and Battery Updates
- Depression Therapy
- Task reminder

STEPS TO RUN
- Clone this repository (or Download zip file)
- Download NLTK Libraries
- Install dependencies using from pip install
- Run the python 3.9 interpreter
- Give voice commands mentioning the assistant name


