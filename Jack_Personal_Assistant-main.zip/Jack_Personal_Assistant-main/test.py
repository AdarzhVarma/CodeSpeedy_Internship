from nltk.tokenize import word_tokenize

sentence=" hey NYX what is the date today"

output=word_tokenize(sentence)
#print(output)


